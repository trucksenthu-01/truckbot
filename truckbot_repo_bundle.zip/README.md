# TrucksEnthusiasts Chatbot (Affiliate-aware)
(abridged for zip bundle, see chat for full markdown)